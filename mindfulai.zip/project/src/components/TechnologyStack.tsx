import React from 'react';
import { Code2, Database, Brain, Shield } from 'lucide-react';

const technologies = [
  {
    icon: Brain,
    name: 'Natural Language Processing',
    description: 'Advanced NLP algorithms for understanding context and emotion',
  },
  {
    icon: Database,
    name: 'Real-time Processing',
    description: 'Instant response generation using state-of-the-art AI models',
  },
  {
    icon: Shield,
    name: 'Security',
    description: 'End-to-end encryption for complete privacy and security',
  },
  {
    icon: Code2,
    name: 'Modern Stack',
    description: 'Built with React, TypeScript, and cutting-edge web technologies',
  },
];

export default function TechnologyStack() {
  return (
    <div className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold sm:text-4xl">
            Powered by Advanced Technology
          </h2>
          <p className="mt-4 text-gray-400 text-xl">
            Our platform combines cutting-edge technologies to provide the best support
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {technologies.map((tech) => (
            <div
              key={tech.name}
              className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition-colors"
            >
              <div className="flex items-center justify-center mb-4">
                <tech.icon className="w-8 h-8 text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold text-center mb-2">
                {tech.name}
              </h3>
              <p className="text-gray-400 text-center">{tech.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}