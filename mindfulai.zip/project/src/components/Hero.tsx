import React from 'react';
import { Bot } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-gradient-to-b from-blue-600 to-blue-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="text-center">
          <div className="flex justify-center mb-8">
            <div className="bg-white/10 rounded-full p-4">
              <Bot className="w-12 h-12" />
            </div>
          </div>
          <h1 className="text-4xl font-bold sm:text-5xl md:text-6xl mb-6">
            Your AI Mental Health Companion
          </h1>
          <p className="text-xl text-blue-100 max-w-2xl mx-auto mb-8">
            Experience compassionate support powered by advanced AI. Available 24/7 to listen, understand, and guide you through your mental health journey.
          </p>
          <div className="flex justify-center gap-4">
            <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-colors">
              Start Chatting
            </button>
            <button className="bg-blue-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-400 transition-colors">
              Learn More
            </button>
          </div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-b from-transparent to-white"></div>
    </div>
  );
}