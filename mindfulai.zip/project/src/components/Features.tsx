import React from 'react';
import { Brain, Clock, Heart, Shield } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'AI-Powered Understanding',
    description: 'Advanced natural language processing to understand and respond to your emotions and needs.',
  },
  {
    icon: Clock,
    title: '24/7 Availability',
    description: 'Access support whenever you need it, day or night, without waiting.',
  },
  {
    icon: Heart,
    title: 'Empathetic Support',
    description: 'Trained to provide compassionate, non-judgmental support for your mental well-being.',
  },
  {
    icon: Shield,
    title: 'Private & Secure',
    description: 'Your conversations are completely private and protected with enterprise-grade security.',
  },
];

export default function Features() {
  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Features & Benefits
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Discover how MindfulAI can support your mental well-being
          </p>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="relative bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="absolute top-0 -translate-y-1/2 left-1/2 -translate-x-1/2">
                <div className="bg-blue-600 rounded-full p-3">
                  <feature.icon className="w-6 h-6 text-white" />
                </div>
              </div>
              <div className="pt-8">
                <h3 className="text-xl font-semibold text-gray-900 text-center mb-4">
                  {feature.title}
                </h3>
                <p className="text-gray-600 text-center">
                  {feature.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}