import React from 'react';
import Hero from './components/Hero';
import ChatInterface from './components/ChatInterface';
import Features from './components/Features';
import TechnologyStack from './components/TechnologyStack';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Hero />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Try MindfulAI Now
          </h2>
          <p className="mt-4 text-xl text-gray-600">
            Experience our AI-powered mental health support firsthand
          </p>
        </div>
        <ChatInterface />
      </div>

      <Features />
      <TechnologyStack />
      
      <footer className="bg-gray-50 border-t py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-gray-600">
          <p>© 2024 MindfulAI. All rights reserved.</p>
          <p className="mt-2">
            If you're experiencing a mental health emergency, please contact your local emergency services or crisis hotline immediately.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;